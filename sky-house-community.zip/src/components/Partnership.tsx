import { motion } from "motion/react";

const partners = [
  { name: "Partner 1", logo: "https://picsum.photos/seed/p1/200/100" },
  { name: "Partner 2", logo: "https://picsum.photos/seed/p2/200/100" },
  { name: "Partner 3", logo: "https://picsum.photos/seed/p3/200/100" },
  { name: "Partner 4", logo: "https://picsum.photos/seed/p4/200/100" },
  { name: "Partner 5", logo: "https://picsum.photos/seed/p5/200/100" },
  { name: "Partner 6", logo: "https://picsum.photos/seed/p6/200/100" },
];

export default function Partnership() {
  return (
    <section id="partnership" className="py-24 border-t border-border">
      <div className="container-custom">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl mb-4"
          >
            Our <span className="text-primary">Partners</span>
          </motion.h2>
          <p className="text-muted-foreground">Bekerja sama dengan berbagai komunitas dan brand ternama.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center">
          {partners.map((partner, i) => (
            <motion.div
              key={partner.name}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="grayscale hover:grayscale-0 opacity-50 hover:opacity-100 transition-all duration-300"
            >
              <img 
                src={partner.logo} 
                alt={partner.name} 
                className="h-12 w-auto mx-auto object-contain"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
